from azure.storage.blob import BlockBlobService

import logging
import pandas
import json

import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')


    #account_name='blobfunction'
    #account_key='F1cVszo5C5AMDE7qi6lv+q5tOPorcYrztvZ7mX4VHI/6fAxZa/INDS7LnrBCjAv2IE4TvbdRh27EeUaLBfKp+w=='
    #blob_name='sample-response-batch-read.json'
    #container_name='luisd-input'
    #output_container='luisd-input'
    #output_fileName='luisd-input.txt'

    account_name=req.headers.get('account_name')
    account_key=req.headers.get('account_key')
    blob_name=req.headers.get('blob_name')
    container_name=req.headers.get('container_name')
    output_container=req.headers.get('output_container')
    output_fileName=req.headers.get('output_fileName')


    blob_service = BlockBlobService(account_name=account_name, account_key=account_key)
    blob = blob_service.get_blob_to_bytes(container_name, blob_name)
    blob1 = blob_service.get_blob_to_text(container_name, blob_name)
    data = blob1.content
    #data1=data.decode()
    #type(data)

    data1=json.loads(data)

    data2=data1["recognitionResults"][0]['lines']

    line_infos = [item["text"] for item in data2]
    #type(line_infos[0:])
    output = '  '.join(line_infos)

    blob_service.create_blob_from_text(output_container,output_fileName, output)

    return func.HttpResponse(output,headers={'Content-Type':'application/json'})
